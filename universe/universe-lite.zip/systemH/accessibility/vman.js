document.addEventListener('DOMContentLoaded', function() {

var brightnessContainer = document.getElementById('brightnessContainer');
var brightnessRange = document.getElementById('brightness');

brightnessRange.addEventListener("input", function() {
    const brightnessValue = this.value / 100;
    brightnessContainer.style.backgroundColor = `rgba(0, 0, 0, ${1 - brightnessValue})`;
});
});

function askValue(text, onclick) {
	document.getElementById('askValueButton2').addEventListener('click', closeAskValue);
    document.getElementById('askValueButton').addEventListener('click', closeAskValue);

    let p2 = document.getElementById('p2');
    let askValueContainer = document.getElementById('askValue');
    
    askValueContainer.style.display = "block";
    p2.innerHTML = text;
    document.getElementById('askValueInput').value = "";
    document.getElementById('askValueButton').onclick = onclick;
}


function closeAskValue() {
    let p2 = document.getElementById('p2');
    let askValueContainer = document.getElementById('askValue');

    askValueContainer.style.display = "none";
    p2.innerHTML = "No Message";
    document.getElementById('saveFilesOutput').style.display = "none";
}

function ask(text, onclick) {
	document.getElementById('askButton2').addEventListener('click', closeAsk);
    document.getElementById('askButton').addEventListener('click', closeAsk);

	let p3 = document.getElementById('p3');
	let askContainer = document.getElementById('ask');

	askContainer.style.display = "block";
	p3.innerHTML = text;
	document.getElementById('askButton').onclick = onclick;
}

function closeAsk() {
	let p3 = document.getElementById('p3');
    let askContainer = document.getElementById('ask');

    askContainer.style.display = "none";
    p3.innerHTML = "No Message";
}

function toggletheme() {
    let padIcons = document.querySelectorAll('.padIcon');
    let buttons = document.querySelectorAll('.button, .input');
    let dockbs = document.querySelectorAll('.dock-accIcon');
	let windows = document.querySelectorAll('.window, .window2');
	let docks = document.querySelectorAll('.dock');
	let tablinks = document.querySelectorAll('.tablink');
	let accicons = document.querySelectorAll('.accIcon');
	let filesaccicons = document.querySelectorAll('.files-accIcon');

    if (theme == 'light') {
        theme = 'dark';
        padIcons.forEach(function(padIcon) {
            padIcon.style.backgroundColor = "rgb(97, 97, 97, 0.7)";
            padIcon.style.border = "2px solid black";
        });

		windows.forEach(function(window) {
			window.style.backgroundColor = "rgb(97, 97, 97, 0.7)";
		});

		buttons.forEach(function(button) {
			button.style.backgroundColor = "rgb(97, 97, 97)";
			button.style.border = "4px solid rgb(97, 97, 97)";
		});

		docks.forEach(function(dock) {
			dock.style.backgroundColor = "rgb(97, 97, 97, 0.7)";
			dock.style.borderTop = "4px solid black";
		});

		dockbs.forEach(function(dockb) {
    		dockb.style.backgroundColor = "rgb(97, 97, 97)";
    		dockb.style.border = "2px solid rgb(97, 97, 97)";
		});

		tablinks.forEach(function(tablink) {
			tablink.style.backgroundColor = "rgb(97, 97, 97)";
			tablink.style.color = "white";
		});

		accicons.forEach(function(accicon) {
			accicon.style.backgroundColor = "rgb(97, 97, 97)";
    		accicon.style.border = "4px solid rgb(97, 97, 97)";
		});

		filesaccicons.forEach(function(filesaccicon) {
			filesaccicon.style.backgroundColor = "rgb(97, 97, 97)";
    		filesaccicon.style.border = "4px solid rgb(97, 97, 97)";
		});
		saveTheme();
    } else if (theme == 'dark') {
        theme = 'light';
        padIcons.forEach(function(padIcon) {
            padIcon.style.backgroundColor = "rgb(0, 142, 189, 0.7)";
            padIcon.style.border = "2px solid rgb(0, 142, 189)";
        });

		windows.forEach(function(window) {
			window.style.backgroundColor = "rgb(240, 248, 255, 0.9)";
		});

		buttons.forEach(function(button) {
			button.style.backgroundColor = "rgb(0, 142, 189)";
			button.style.border = "4px solid rgb(0, 142, 189)";
		});

		docks.forEach(function(dock) {
			dock.style.backgroundColor = "rgb(194, 226, 255, 0.7)";
			dock.style.borderTop = "4px solid #85c6ff";
		});

		dockbs.forEach(function(dockb) {
			dockb.style.backgroundColor = "#85c6ff";
			dockb.style.border = "2px solid #85c6ff";
		});

		tablinks.forEach(function(tablink) {
			tablink.style.backgroundColor = "aliceblue";
			tablink.style.color = "black";
		});

		accicons.forEach(function(accicon) {
			accicon.style.backgroundColor = "rgb(0, 142, 189)";
    		accicon.style.border = "4px solid rgb(0, 142, 189)";
		});

		filesaccicons.forEach(function(filesaccicon) {
			filesaccicon.style.backgroundColor = "rgb(0, 142, 189)";
    		filesaccicon.style.border = "4px solid rgb(0, 142, 189)";
		});
		saveTheme();
    }
}