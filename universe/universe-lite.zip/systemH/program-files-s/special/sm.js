function powerwash() {
    ask('Everything will be lost!<br>Continue?', function() {
        clearInterval(constantRunning);
        localStorage.clear();
        noti('Powerwash will finish after restart');
        setTimeout(function(){
            noti('Clearing');
			publicPassword = "";
			hint = "Hint: There is no hint";
			username = "Public";
			document.getElementById('usernameOutput').innerHTML = username;
			setTimeout(function() {
    			restart();
           	}, 2000);
        }, 3000);
    });
}