document.addEventListener("DOMContentLoaded", function() {
    var input = document.getElementById("commandInput");
    var output = document.getElementById('commandOutput');

    input.addEventListener("keypress", function(event) {
        if (event.key === "Enter") {
            var inputValue = input.value.trim();
            var response = "";
            
            if (inputValue !== "") {
                if (inputValue == "exit") {
                    document.getElementById('command').style.display = "none";
                    document.getElementById('deskpad').style.display = "block";
                    output.innerHTML = '';
                } else if (inputValue == "help") {
                    response = "Commands: exit, help, restart, shutdown";
                } else if (inputValue.startsWith("filesystem --open:")) {
                    var filename = inputValue.split(':')[1].trim();
                    openFile(filename);
                    document.getElementById('command').style.display = "none";
                    document.getElementById('textEditor').style.display = "block";
                } else if (inputValue == "filesystem --list") {
                    listFiles();
                } else if (inputValue == "universe.filesystem.create:testfile") {
                    if (localStorage.getItem('testfile') !== null) {
                        localStorage.removeItem('testfile');
                        localStorage.setItem('testfile', "This is a test file created in the command prompt for purposes determined by the user.");
                        response = "Created a test file";
                    } else {
                        localStorage.setItem('testfile', "This is a test file created in the command prompt for purposes determined by the user.");
                        response = "Created a test file";
                    }
                } else if (inputValue == "shutdown") {
                    saveStorage();
                    inputValue.value = "";
                    window.close();
                } else if (inputValue == "restart") {
                    saveStorage();
                    location.reload();
                } else if (inputValue == "restart:bypass-save") {
                    location.reload();
                } else if (inputValue == "shutdown:bypass-save") {
                    inputValue.value = "";
                    window.close();
                } else if (inputValue == "help:advanced") {
                    response = "restart:bypass-save <br> shutdown:bypass-save";
                } else if (inputValue == "universe.filesystem:clear") {
                    localStorage.clear();
                    response = "Universe Filesystem Cleared";
                } else if (inputValue == "clear") {
                    output.innerHTML = '';
                } else if (inputValue == "help:universe.filesystem") {
                    response = "universe.filesystem.create:testfile <br> universe.filesystem:clear";
                } else if (inputValue.startsWith("filesystem --create:")) {
                    var parts = inputValue.split(':');
                    if (parts.length === 2) {
                        var filename = parts[1].trim();
                        if (filename !== "") {
                            if (localStorage.getItem(filename) !== null) {
                                localStorage.removeItem(filename);
                            }
                            localStorage.setItem(filename, "Command Created File");
                            response = "Created file: " + filename;
                        } else {
                            response = "No filename specified.";
                        }
                    } else {
                        response = "Invalid command syntax. Please specify a filename.";
                    }
                } else if (inputValue == "help:filesystem") {
                    response = "filesystem --create:filename <br> filesystem --delete:filename";
                } else if (inputValue.startsWith("filesystem --delete:")) {
                    var parts = inputValue.split(':');
                    if (parts.length === 2) {
                        var filename = parts[1].trim();
                        if (filename !== "") {
                            if (localStorage.removeItem(filename) !== null) {
                                localStorage.removeItem(filename);
                            }
                            localStorage.removeItem(filename);
                            response = "Deleted File: " + filename;
                        } else {
                            response = "No filename specified.";
                        }
                    } else {
                        response = "Invalid command syntax. Please specify a filename.";
                    }
                } else {
                    response = "That is not a command, please type help.";
                }
            }
            output.innerHTML += response + "<br>";
            input.value = "";
        }
    });

    function openFile(filename) {
        var content = localStorage.getItem(filename);
        if (content !== null) {
            // Display file content in the text editor
            document.getElementById('editor').value = content;
        } else {
            output.innerHTML += "File not found: " + filename + "<br>";
        }
    }

    function listFiles() {
        var filesInfo = "";
        for (var i = 0; i < localStorage.length; i++) {
            var key = localStorage.key(i);
            var value = localStorage.getItem(key);
            var fileSize = formatBytes((key.length + value.length) * 2); // Calculate size
            filesInfo += key + " (" + fileSize + ")<br>";
        }
        output.innerHTML += filesInfo;
    }

    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';

        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

        const i = Math.floor(Math.log(bytes) / Math.log(k));

        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }
});