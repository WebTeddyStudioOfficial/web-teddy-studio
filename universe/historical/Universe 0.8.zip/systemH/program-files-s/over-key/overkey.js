document.onkeydown = function(e) { 
        switch (e.keyCode) { 
            case 27:
            openApp('powerMenu');
            break;

            case 18:
                document.getElementById('load').style.display = "none";
	        document.getElementById('login').style.display = "none";
	        document.getElementById('info').style.display = "none";
	        document.getElementById('files').style.display = "none";
	        document.getElementById('textEditor').style.display = "none";
        	document.getElementById('deskpad').style.display = "none";
        	document.getElementById('login').style.display = "none";
          document.getElementById('execute').style.display = "none";
          document.getElementById('powerMenu').style.display = "none";
          document.getElementById('command').style.display = "block";
          break;
        } 
    };