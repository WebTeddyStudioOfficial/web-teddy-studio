function openTab(tabName) {
    var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablink");
        for (i = 0; i < tablinks.length; i++) {
        }
        document.getElementById(tabName).style.display = "block";
  }
  
  function openApp(appName) {
    document.getElementById('command').style.display = "none";
      document.getElementById(appName).style.display = "block";
      document.getElementById('deskpad').style.display = "none";
	  if (appName == "powerMenu") {
            document.getElementById('load').style.display = "none";
	        document.getElementById('login').style.display = "none";
	        document.getElementById('info').style.display = "none";
	        document.getElementById('files').style.display = "none";
	        document.getElementById('textEditor').style.display = "none";
        	document.getElementById('deskpad').style.display = "none";
        	document.getElementById('login').style.display = "none";
          document.getElementById('command').style.display = "none";
          document.getElementById('execute').style.display = "none";
          document.getElementById('powerMenu').style.display = "block";
	  } else if (appName == "files") {
          displayLocalStorage();
          displayAmounts();
      }
  }
  
  function closeApp(appName) {
      document.getElementById(appName).style.display = "none";
      document.getElementById('deskpad').style.display = "block";
	  if (appName == "textEditor") {
		  document.getElementById('editor').value = "";
	  }
  }