function saveText() {
    var filename = prompt("Enter a filename:");

    // Check if the user clicked cancel
    if (filename === null) {
        alert("Save operation cancelled.");
        return;
    }

    filename = filename.trim() + ".txt";
    
    // Check if a filename was provided
    if (!filename.trim()) {
        alert("Please enter a filename.");
        return;
    }

    // Check if a file with the same name already exists
    if (localStorage.getItem(filename) !== null) {
        var overwrite = confirm("A file with the same name already exists. Do you want to overwrite it?");
        if (!overwrite) {
            return; // Exit the function if the user chooses not to overwrite
        }
    }

    var text = document.getElementById('editor').value;
    localStorage.setItem(filename, text);
    alert("Saved as: " + filename);
}


	function loadText1() {
		document.getElementById('textEditor').style.display = "none";
		document.getElementById('files').style.display = "block";
		displayLocalStorage();
		openTab('filesContent');
	}

    function loadText(key) {
        document.getElementById('editor').value = localStorage.getItem(key) || "No Content";
		document.getElementById('files').style.display = "none";
		document.getElementById('textEditor').style.display = "block";
		openTab('text');
    }

	    function removeText() {
			document.getElementById('textEditor').style.display = "none";
			document.getElementById('files').style.display = "block";
			displayLocalStorage();
			openTab('filesContent');
    }

    function applyStyles() {
        var fontSize = document.getElementById('fontsize').value + "px";
        var fontColor = document.getElementById('fontcolor').value;
        var fontFamily = document.getElementById('fontfamily').value;
        var textAlign = document.getElementById('textalign').value;
        
        var editor = document.getElementById('editor');
        editor.style.fontSize = fontSize;
        editor.style.color = fontColor;
        editor.style.fontFamily = fontFamily;
        editor.style.textAlign = textAlign;
    }

function downloadText() {
    var textToDownload = document.getElementById('editor').value;
    var filename = prompt("Enter a filename for the download:");
    
    if (!filename || !filename.trim()) {
        alert("Please enter a filename.");
        return;
    }
    
    var blob = new Blob([textToDownload], { type: 'text/plain' });
    var link = document.createElement('a');
    link.download = filename;
    link.href = window.URL.createObjectURL(blob);
    link.click();
}