var filesDisplayStatus = 1;

function displayLocalStorage() {
    var localStorageContents = "";
    for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        var value = localStorage.getItem(key);
        var fileSize = formatBytes((key.length + value.length) * 2); // Calculate size
        localStorageContents += '<p class="files-section">' + '<span class="files-span">S:/Files/</span>' + key + '<button class="files-button" onClick="loadText(\'' + key + '\')">Open</button><button class="files-button" onclick="deleteItem(\'' + key + '\')">Delete</button><button class="files-button" onClick="downloadFile(\'' + key + '\')">Download</button><button class="files-button" onClick="filesExecute(\'' + key + '\')">Execute</button><span class="filesizespan"><b>(' + fileSize + ')</b>&nbsp;</span></p>';
    }
    document.getElementById("localStorageContents").innerHTML = localStorageContents;
    if (key == null) {
        document.getElementById('localStorageContents').innerHTML = "No Files";
    }
    filesDisplayStatus = 1;
}

  function deleteItem(key) {
	localStorage.removeItem(key);
	  loadStorage();
      if (filesDisplayStatus == 1) {
	displayLocalStorage();
      } else if (filesDisplayStatus == 2) {
        showContent();
      }
  }

function showContent() {
    var localStorageContents = "";
    for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        var value = localStorage.getItem(key);
        // Display only 65 characters followed by three dots if the length exceeds 65
        var displayValue = value.length > 65 ? value.substring(0, 65) + "..." : value;
        localStorageContents += '<p class="files-section">' + '<span class="files-span">S:/Files/</span>' + key + ": <br><b>" + displayValue + ' </b><button class="files-button" onClick="loadText(\'' + key + '\')">Open</button><button class="files-button" onclick="deleteItem(\'' + key + '\')">Delete</button><button class="files-button" onClick="downloadFile(\'' + key + '\')">Download</button><button class="files-button" onClick="filesExecute(\'' + key + '\')">Execute</button><span class="filesizespan"><b>(' + fileSize + ')</b>&nbsp;</span></p>';
    }
    document.getElementById("localStorageContents").innerHTML = localStorageContents;
    if (key == null) {
        document.getElementById('localStorageContents').innerHTML = "No Files";
    }
    filesDisplayStatus = 2;
}

function downloadFile(key) {
    var textToDownload = localStorage.getItem(key);
    var filename = prompt("Enter a filename for the download:");
    
    if (!filename || !filename.trim()) {
        alert("Please enter a filename.");
        return;
    }
    
    var blob = new Blob([textToDownload], { type: 'text/plain' });
    var link = document.createElement('a');
    link.download = filename;
    link.href = window.URL.createObjectURL(blob);
    link.click();
}

function handleFileSelect(event) {
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(event) {
                const content = event.target.result;
                const key = prompt("Please enter a name for this file:");
                if (key) {
                    localStorage.setItem(key, content);
                    alert("File saved");
					displayLocalStorage();
                } else {
                    alert("No filename provided. File not saved");
					displayLocalStorage();
                }
            };
            reader.readAsText(file);
            if (filesDisplayStatus == 1) {
                displayLocalStorage();
                  } else if (filesDisplayStatus == 2) {
                    showContent();
                  }
        }

function filesExecute(key) {
    const executableCode = localStorage.getItem(key);
    
    if (!executableCode) {
        alert('Not an executable');
        return;
    }
    
    try {
        eval(executableCode);
        
        if (typeof runExecutable !== 'function') {
            alert('This executable is missing the run code. Is it for Universe?');
            return;
        }
        
        runExecutable();
    } catch (error) {
        console.error('File is not eux', error);
        alert('File is not uex.');
    }
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function displayAmounts() {
    var totalStorage = 0;
    var totalFiles = 0;

    // Iterate through localStorage keys
    for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        var value = localStorage.getItem(key);

        // Calculate total storage used
        totalStorage += (key.length + value.length) * 2; // 16-bit encoding

        // Increment total number of files
        totalFiles++;
    }

    // Display total storage used and total number of files
    document.getElementById("totalStorage").textContent = 'Total Size: ' + formatBytes(totalStorage);
    document.getElementById("totalFiles").textContent = 'Files: ' + totalFiles;
}