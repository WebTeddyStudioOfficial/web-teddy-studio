let hint = "Hint: " + "There is no hint";
let username = "Public";

function shutdown() {
	saveStorage();
	window.close();
}

function restart() {
	logout();
}

function update() {
	saveStorage();
	location.reload();
}

function logout() {
    hideAllWindows();
    document.getElementById('login').style.display = 'block';
}

function finishLoad() {
    loadStorage();
    hideAllWindows();
    document.getElementById('login').style.display = 'block';
}

function loadStorage() {
	publicPassword = localStorage.getItem('password') || "";
	hint = localStorage.getItem('hint') || "Hint: " + "There is no hint";
	username = localStorage.getItem('username') || "Public";
	document.getElementById('usernameOutput').innerHTML = username;
}

function saveStorage() {
	localStorage.setItem('password', publicPassword);
	localStorage.setItem('hint', hint);
	localStorage.setItem('username', username);
}

function clearStorage() {
    const keysToKeep = ["username", "password", "hint"]; // Define the keys to keep

    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!keysToKeep.includes(key)) {
            localStorage.removeItem(key);
        }
    }

    loadStorage();
    displayLocalStorage();
    displayAmounts();
}

function hideAllWindows() {
    document.querySelectorAll('.window, .window2').forEach(function (element) {
        element.style.display = 'none';
    });
}

document.addEventListener('DOMContentLoaded', function() {
  var dockElements = document.querySelectorAll('.dock');
  var windowElements = document.querySelectorAll('.window');

  dockElements.forEach(function(dockElement) {
    var dockHeight = dockElement.offsetHeight;
    windowElements.forEach(function(windowElement) {
      windowElement.style.height = 'calc(100% - ' + dockHeight + 'px)';
    });
  });
});