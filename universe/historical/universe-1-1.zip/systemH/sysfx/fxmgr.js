var efx = new Audio('systemH/sysfx/efx.mp3');
var nfx = new Audio('systemH/sysfx/nfx.mp3');