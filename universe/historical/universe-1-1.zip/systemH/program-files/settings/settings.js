function changeHint() {
	hint = "Hint: " + document.getElementById('changeHintInput').value;
	if (hint == "Hint: " + document.getElementById('changeHintInput').value) {
		noti('Hint Changed');
		document.getElementById('changeHintInput').value = "";
	} else  {
		noti('There was a problem changing the hint');
		document.getElementById('changeHintInput').value = "";
	}
	saveStorage();
	loadStorage();
}

function changePassword() {
	if (document.getElementById('changePasswordInput').value == document.getElementById('changePasswordInput2').value) {
		publicPassword = document.getElementById('changePasswordInput').value;
		if (publicPassword == document.getElementById('changePasswordInput').value) {
			noti('Password Changed');
			document.getElementById('changePasswordInput').value = ""; 
			document.getElementById('changePasswordInput2').value = "";
			} else {
			noti('There was a problem changing your password');
		}
	} else {
		noti('Passwords are not the same');
	}
	saveStorage();
	loadStorage();
}

function changeUsername() {
	username = document.getElementById('changeUsernameInput').value;
	if (username == document.getElementById('changeUsernameInput').value) {
		noti('Username has been changed');
		document.getElementById('changeUsernameInput').value = "";
		document.getElementById('usernameOutput').innerHTML = username;
	} else {
		document.getElementById('changeUsernameInput').value = "";
		noti('There was a problem changing your password');
	}
	saveStorage();
	loadStorage();
}

function changeTabsColor() {
	var tabsBar = document.querySelectorAll('.tabs');
	tabsBar.forEach(function(tabsBar) {
		tabsBar.style.borderColor = document.getElementById('changeColorsTabs').value;
				   });
}

function changeDeskpadColor() {
	var deskpad = document.querySelectorAll('body');
	deskpad.forEach(function(deskpad) {
		deskpad.style.backgroundColor = document.getElementById('changeColorsDeskpad').value;
   });
}

function changeWindowColor() {
	var window = document.querySelectorAll('.window');
	var tabcontent = document.querySelectorAll('.tabcontent');
	window.forEach(function(window) {
		window.style.backgroundColor = document.getElementById('changeColorsWindow').value;
		window.style.borderColor = document.getElementById('changeColorsWindow').value;
	});
	tabcontent.forEach(function(tabcontent) {
		tabcontent.style.backgroundColor = document.getElementById('changeColorsWindow').value;
		tabcontent.style.borderColor = document.getElementById('changeColorsWindow').value;
	});
}

function setNotiTimeout() {
	notiTimeout = document.getElementById('newNotiTimeout').value * 1000;
}

function settingsFn(fn) {
	if (fn == "deletePassword") {
		publicPassword = "";
		saveStorage();
		loadStorage();
		noti('Password has been deleted');
	} else if (fn == "deleteUsername") {
		username = "";
		saveStorage();
		loadStorage();
		noti('Username has been deleted');
	} else if (fn == "deleteHint") {
		hint = "";
		saveStorage();
		loadStorage();
		noti('Hint has been deleted');
	}
}

function changeDockBorderColor() {
	var border1 = document.querySelectorAll('.dock');
	var border2 = document.querySelectorAll('.dock-accIcon');
	border1.forEach(function(border1) {
		border1.style.borderColor = document.getElementById('changeColorsDockBorder').value;
	});
	border2.forEach(function(border2) {
		border2.style.borderColor = document.getElementById('changeColorsDockBorder').value;
	});
}

function changeDockColor() {
	var dock = document.querySelectorAll('.dock');
	dock.forEach(function(dock) {
		dock.style.backgroundColor = document.getElementById('changeColorsDock').value;
	});
}