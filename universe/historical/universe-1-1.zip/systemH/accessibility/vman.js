document.addEventListener('DOMContentLoaded', function() {

var brightnessContainer = document.getElementById('brightnessContainer');
var brightnessRange = document.getElementById('brightness');

brightnessRange.addEventListener("input", function() {
    const brightnessValue = this.value / 100; // Normalize value to range 0 to 1
    brightnessContainer.style.backgroundColor = `rgba(0, 0, 0, ${1 - brightnessValue})`;
});
});