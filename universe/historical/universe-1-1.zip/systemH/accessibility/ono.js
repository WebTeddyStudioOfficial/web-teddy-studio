var notiTimeout = 3000;
var ntype = "normal";

function noti(message) {
    var noti = document.getElementById('notification');
    if (noti) {
        var p = document.getElementById('p');
        noti.style.display = "block";
        p.innerHTML = message;
		if (ntype == "error") {
			efx.play();
			ntype = "normal";
		} else {
			nfx.play();
		}
        setTimeout(function() {
            p.innerHTML = "";
            noti.style.display = "none";
        }, notiTimeout);
    }
}

window.onerror = function(message, source, lineno, colno, error) {
    var errorMessage = error ? (error.message || error.toString()) : message;
    noti("Error: " + errorMessage);
	ntype = "error";
    return false;
};
