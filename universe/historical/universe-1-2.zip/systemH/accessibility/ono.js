var notiTimeout = 3000;
var ntype = "normal";

function noti(message) {
    var noti = document.getElementById('notification');
	var p = document.getElementById('p');
    if (ntype == "normal") {
		noti.style.display = "block";
		p.innerHTML = message;
		nfx.play();
	} else {
		noti.style.display = "block";
		p.innerHTML = message;
		efx.play();
		ntype = "normal";
	}
	setTimeout(function() {
		noti.style.display = "none";
	}, notiTimeout);
}

window.onerror = function(message, source, lineno, colno, error) {
    var errorMessage = error ? (error.message || error.toString()) : message;
    noti("Error: " + errorMessage);
	ntype = "error";
    return false;
};