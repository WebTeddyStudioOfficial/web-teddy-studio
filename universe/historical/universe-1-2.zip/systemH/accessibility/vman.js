document.addEventListener('DOMContentLoaded', function() {

var brightnessContainer = document.getElementById('brightnessContainer');
var brightnessRange = document.getElementById('brightness');

brightnessRange.addEventListener("input", function() {
    const brightnessValue = this.value / 100;
    brightnessContainer.style.backgroundColor = `rgba(0, 0, 0, ${1 - brightnessValue})`;
});
});

function askValue(text, onclick) {
	document.getElementById('askValueButton2').addEventListener('click', closeAskValue);
    document.getElementById('askValueButton').addEventListener('click', closeAskValue);
    let p2 = document.getElementById('p2');
    let askValueContainer = document.getElementById('askValue');
    
    askValueContainer.style.display = "block";
    p2.innerHTML = text;
    document.getElementById('askValueInput').value = "";
    document.getElementById('askValueButton').onclick = onclick;
}


function closeAskValue() {
    let p2 = document.getElementById('p2');
    let askValueContainer = document.getElementById('askValue');

    askValueContainer.style.display = "none";
    p2.innerHTML = "No Message";
    document.getElementById('saveFilesOutput').style.display = "none";
}

function ask(text, onclick) {
	document.getElementById('askButton2').addEventListener('click', closeAsk);
    document.getElementById('askButton').addEventListener('click', closeAsk);
	let p3 = document.getElementById('p3');
	let askContainer = document.getElementById('ask');

	askContainer.style.display = "block";
	p3.innerHTML = text;
	document.getElementById('askButton').onclick = onclick;
}

function closeAsk() {
	let p3 = document.getElementById('p3');
    let askContainer = document.getElementById('ask');

    askContainer.style.display = "none";
    p3.innerHTML = "No Message";
}