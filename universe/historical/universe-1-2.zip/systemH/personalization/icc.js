let currentIconIndex = 0;
const iconPaths = [
    'systemH/personalization/usericon1.png',
    'systemH/personalization/usericon2.png',
    'systemH/personalization/usericon3.png',
    'systemH/personalization/usericon4.png',
    'systemH/thumbnails/user.png'
];

// Load the selected icon from localStorage on page load
document.addEventListener('DOMContentLoaded', function () {
    const savedIconIndex = localStorage.getItem('selectedIconIndex');
    if (savedIconIndex !== null) {
        currentIconIndex = parseInt(savedIconIndex);
        updateMainIcon();
    }
});

function changeIcon(iconPath) {
    currentIconIndex = iconPaths.indexOf(iconPath);
    updateMainIcon();
    saveSelectedIcon();
}

function updateMainIcon() {
    const mainIconElement = document.getElementById('mainIcon');
    mainIconElement.src = iconPaths[currentIconIndex];
}

function saveSelectedIcon() {
    localStorage.setItem('selectedIconIndex', currentIconIndex.toString());
}