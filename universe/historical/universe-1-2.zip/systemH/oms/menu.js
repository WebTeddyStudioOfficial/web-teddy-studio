const contextMenu = document.getElementById('customContextMenu');

document.addEventListener('contextmenu', function (e) {
    e.preventDefault();
    const x = e.clientX;
    const y = e.clientY;
    contextMenu.style.left = `${x}px`;
    contextMenu.style.top = `${y}px`;
    contextMenu.style.display = 'block';
});

document.addEventListener('click', function () {
    contextMenu.style.display = 'none';
});