function publicLogin() {
	var passwordInput = document.getElementById('passwordInput');

	if (passwordInput.value == publicPassword) {
		document.getElementById('login').style.display = "none";
		document.getElementById('deskpad').style.display = "flex";
		document.getElementById('hintOutput').innerHTML = "";
		noti('Welcome, ' + username);
		logStatus_PATCH = true;
		passwordInput.value = "";
	} else if (passwordInput.value == masterPassword) {
		document.getElementById('login').style.display = "none";
		document.getElementById('deskpad').style.display = "flex";
		document.getElementById('hintOutput').innerHTML = "";
		noti('Welcome, ' + username);
		passwordInput.value = "";
		logStatus_PATCH = true;
	} else {
		document.getElementById('hintOutput').innerHTML = hint;
		noti('Sorry. Incorrect Password');
		logStatus_PATCH = false;
	}
}