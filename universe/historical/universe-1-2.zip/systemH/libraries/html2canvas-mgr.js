function convertCodeToImage(imgkey) {
    // Retrieve code from localStorage
    var code = localStorage.getItem(imgkey);

    // Check if the code is not empty
    if (!code) {
        noti("Code is empty. Cannot convert to image.");
        return;
    }

    // Create a new div element to hold the code
    var codeContainer = document.createElement('div');
    codeContainer.innerText = code;
    document.body.appendChild(codeContainer);

    // Use html2canvas to render the code container as an image
    html2canvas(codeContainer, {
        onrendered: function(canvas) {
            // Convert canvas to data URL
            const imageDataUrl = canvas.toDataURL();

            // Open the image in a new tab
            const newTab = window.open();
            newTab.document.write('<img src="' + imageDataUrl + '" />');

            // Remove the temporary code container
            document.body.removeChild(codeContainer);
        }
    });
}
