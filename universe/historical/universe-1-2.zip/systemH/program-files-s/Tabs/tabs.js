let logStatus_PATCH = false;

function openTab(tabName) {
    var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
          tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablink");
        for (i = 0; i < tablinks.length; i++) {
        }
        document.getElementById(tabName).style.display = "block";
  }
  
  function openApp(appName) {
    if (logStatus_PATCH == true) {
    hideAllWindows();
      document.getElementById(appName).style.display = "block";
      document.getElementById('deskpad').style.display = "none";
	  if (appName == "files") {
          displayLocalStorage();
      }
    } else {
      noti('You need to login before opening an app');
    }
  }
  
  function closeApp(appName) {
      document.getElementById(appName).style.display = "none";
      document.getElementById('deskpad').style.display = "flex";
	  if (appName == "textEditor") {
		  document.getElementById('editor').value = "";
	  }
  }