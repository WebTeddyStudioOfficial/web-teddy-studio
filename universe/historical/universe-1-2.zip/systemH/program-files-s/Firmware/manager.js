let hint = "Hint: " + "There is no hint";
let username = "Public";
let constantSpeed = 500;

function shutdown() {
	saveStorage();
	window.close();
}

function restart() {
	saveStorage();
	location.reload();
}

function logout() {
    hideAllWindows();
    document.getElementById('loginMenu').style.display = 'block';
    checkPassword();
    logStatus_PATCH = false;
}

function showLogin() {
	hideAllWindows();
	document.getElementById('login').style.display = "block";
}

function finishLoad() {
    loadStorage();
    hideAllWindows();
    document.getElementById('loginMenu').style.display = 'block';
	setInterval(constantRunning, constantSpeed);
}

function constantRunning() {
    saveStorage();
    loadStorage();
	displayAmounts();
    checkPassword();
	updateWindowSize();
    constantAPISupdate();
    constantAPIS();
	updateBatteryLevel();
}

function checkPassword() {
    if (!publicPassword == "") {
        document.getElementById('passwordInput').style.display = "block";
		document.getElementById('h').style.display = "none";
    } else {
        document.getElementById('passwordInput').style.display = "none";
		document.getElementById('h').style.display = "block";
    }
}

function loadStorage() {
	publicPassword = localStorage.getItem('password') || "";
	hint = localStorage.getItem('hint') || "Hint: " + "There is no hint";
	username = localStorage.getItem('username') || "Public";
	document.getElementById('usernameOutput').innerHTML = username;
}

function saveStorage() {
	localStorage.setItem('password', publicPassword);
	localStorage.setItem('hint', hint);
	localStorage.setItem('username', username);
}

function clearStorage() {
    const keysToKeep = ["username", "password", "hint", "selectedIconIndex"];

    for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!keysToKeep.includes(key)) {
            localStorage.removeItem(key);
        }
    }
    loadStorage();
    displayLocalStorage();
    displayAmounts();
}

function hideAllWindows() {
    document.querySelectorAll('.window, .window2, .deskpad, .tabcontent').forEach(function (element) {
        element.style.display = 'none';
    });
}

function updateLoadingStatus() {
            var loadingStatus = document.getElementById('loadingStatus');
            
            // Check if any images are still loading
            var images = document.getElementsByTagName('img');
            for (var i = 0; i < images.length; i++) {
                if (!images[i].complete) {
                    loadingStatus.innerHTML = "Currently loading: " + images[i].src;
                    return;
                }
            }
            
            // Check if any CSS files are still loading
            var links = document.getElementsByTagName('link');
            for (var i = 0; i < links.length; i++) {
                if (links[i].rel === 'stylesheet' && !links[i].sheet) {
                    loadingStatus.innerHTML = "Currently loading: " + links[i].href;
                    return;
                }
            }
            
            // Check if any scripts are still loading
            var scripts = document.getElementsByTagName('script');
            for (var i = 0; i < scripts.length; i++) {
                if (scripts[i].readyState === 'loading') {
                    loadingStatus.innerHTML = "Currently loading: " + scripts[i].src;
                    return;
                }
            }
        }

		document.addEventListener('DOMContentLoaded', function() {
        	updateLoadingStatus();
		});

		function updateWindowSize() {
			var dockElements = document.querySelectorAll('.dock');
  			var windowElements = document.querySelectorAll('.window, .window2');

 			 	dockElements.forEach(function(dockElement) {
  			  	var dockHeight = dockElement.offsetHeight;
   			 	windowElements.forEach(function(windowElement) {
   				windowElement.style.height = 'calc(100% - ' + dockHeight + 'px)';
    });
  });
		}