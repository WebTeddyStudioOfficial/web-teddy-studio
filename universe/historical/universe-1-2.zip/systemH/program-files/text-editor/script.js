function saveText() {
    document.getElementById('saveFilesOutput').style.display = "block";
    displaySaveFiles();
    askValue('Please enter a filename', function() {
        var filename = document.getElementById('askValueInput').value;

        if (!filename) {
            noti("Please enter a filename.");
            return;
        }

        var text = document.getElementById('editor').value;

        if (localStorage.getItem(filename) !== null) {
            // Capture the filename and text before calling ask
            var originalFilename = filename;
            var originalText = text;

            ask('Would you like to overwrite this file?', function() {
                // Use the captured values in the callback
                localStorage.setItem(originalFilename, originalText);
                noti("Saved as: " + originalFilename);
            });
        } else {
            localStorage.setItem(filename, text);
            noti("Saved as: " + filename);
        }
    });
}


function loadText1() {
    document.getElementById('textEditor').style.display = "none";
    document.getElementById('files').style.display = "block";
    displayLocalStorage();
    displayAmounts();
}

function loadText(key) {
    openApp('textEditor');
	document.getElementById('editor').value = localStorage.getItem(key) || "No Content";
}


function removeText() {
    document.getElementById('textEditor').style.display = "none";
    document.getElementById('files').style.display = "block";
    displayLocalStorage();
    displayAmounts();
}

function downloadText() {
    askValue('Please enter a filename for the download', function() {
        var textToDownload = document.getElementById('editor').value;
        var filename = document.getElementById('askValueInput').value;
    
        if (!filename || !filename.trim()) {
            noti("Please enter a filename.");
            return;
        }
    
        var blob = new Blob([textToDownload], { type: 'text' });
        var link = document.createElement('a');
        link.download = filename;
        link.href = window.URL.createObjectURL(blob);
        link.click();
    });
}

function displaySaveFiles() {
        var localStorageContents = "";
    
        for (var i = 0; i < localStorage.length; i++) {
            var key = localStorage.key(i);
    
            if (systemFiles.includes(key)) {
                continue;
            }
    
            var value = localStorage.getItem(key);
            var fileSize = formatBytes((key.length + value.length) * 2);
    
            localStorageContents += '<p onClick="saveAsFile(\'' + key + '\')" class="files-section">' +
                '<span class="files-span">S:/Files/</span>' + key +
                '<span class="filesizespan"><b>(' + fileSize + ')</b>&nbsp;</span>' +
                '</p>';
        }
        document.getElementById('saveFilesOutput').innerHTML = localStorageContents;
}

function saveAsFile(key) {
    closeAskValue();
    const value = document.getElementById('editor').value;
    ask('Are you sure?', function() {
        localStorage.setItem(key, value);
        noti('Saved as: ' + key);
    });
}