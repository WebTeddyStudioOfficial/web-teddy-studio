var systemFiles = ["username", "password", "hint", "selectedIconIndex"];

function displayLocalStorage() {
    displayAmounts();
    var localStorageContents = "";

    for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);

        if (systemFiles.includes(key)) {
            continue;
        }

        var value = localStorage.getItem(key);
        var fileSize = formatBytes((key.length + value.length) * 2); // Calculate size

        localStorageContents += '<p ondblclick="openFile(\'' + key + '\')" class="files-section">' +
            '<span class="files-span">S:/Files/</span>' + key +
            '<button class="files-section-accIcon" onclick="deleteItem(\'' + key + '\')"><img src="systemH/accessibility/delete.png"></button>' +
            '<button class="files-section-accIcon" onclick="renameFile(\'' + key + '\')"><img src="systemH/accessibility/rename.png"></button>' +
            '<button class="files-section-accIcon" onclick="copyFile(\'' + key + '\')"><img src="systemH/accessibility/copy.png"></button>' +
            '<button class="files-section-accIcon" onClick="downloadFile(\'' + key + '\')"><img src="systemH/accessibility/download.png"></button>' +
            '<button class="files-section-accIcon" onClick="filesExecute(\'' + key + '\', event)"><img src="systemH/accessibility/execute.png"></button>' +
            '<span class="filesizespan"><b>(' + fileSize + ')</b>&nbsp;</span>' +
            '</p>';
    }

    document.getElementById("localStorageContents").innerHTML = localStorageContents;

    if (localStorageContents === "") {
        document.getElementById('localStorageContents').innerHTML = "No Files";
    }
}

function deleteItem(key) {
 	ask('Are you sure?', function() {
        localStorage.removeItem(key);
    	displayLocalStorage();
    	noti('Deleted: ' + key);
		closeAsk();
    });
}

function downloadFile(key) {
    askValue('Please enter a filename for the download', function() {
        var textToDownload = localStorage.getItem(key);
        var filename = document.getElementById('askValueInput').value;
        
        if (!filename || !filename.trim()) {
            noti('Please enter a filename');
            return;
        }
        
        var blob = new Blob([textToDownload], { type: 'text' });
        var link = document.createElement('a');
        link.download = filename;
        link.href = window.URL.createObjectURL(blob);
        link.click();
	});
}

function handleFileSelect(event) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(event) {
        const content = event.target.result;
        
        askValue('Please enter a name for this file:', function() {
            const key = document.getElementById('askValueInput').value;
            if (!key.trim()) {
                noti("No filename provided. File not saved");
                displayLocalStorage();
                return;
            }
            
            const fileNameWithExtension = key;// Append file type to the key
            localStorage.setItem(fileNameWithExtension, content);
            noti("File saved");
            displayLocalStorage();
        });
    };
    reader.readAsText(file);
}

function filesExecute(key) {
    const executableCode = localStorage.getItem(key);
    
    if (!executableCode) {
        noti('No File Contents');
        return;
    }
    
    try {
        eval(executableCode);
        
        if (typeof runExecutable !== 'function') {
            noti('This executable is missing the run code. Is it for Universe?');
            return;
        }
        
        runExecutable();
    } catch (error) {
        noti('File is not uex.');
    }
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function displayAmounts() {
    var totalStorage = 0;
    var totalFiles = 0;
    var systemStorage = 0;

    for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        var value = localStorage.getItem(key);

        totalStorage += (key.length + value.length) * 2;

        totalFiles++;

        if (systemFiles.includes(key)) {
            systemStorage += (key.length + value.length) * 2;
        }
    }

    totalStorage -= systemStorage;
    totalFiles -= systemFiles.length;

    document.getElementById("totalStorage").textContent = 'Total Size: ' + formatBytes(totalStorage);
    document.getElementById("totalFiles").textContent = 'Files: ' + totalFiles;

    document.getElementById("systemStorage").textContent = 'System Size: ' + formatBytes(systemStorage);
    document.getElementById("systemFiles").textContent = 'System Files: ' + systemFiles.length;
}

function executeCode(code) {
	var htmlContent = localStorage.getItem(code);

            if (htmlContent) {
                var blob = new Blob([htmlContent], { type: 'text/html' });
                var url = URL.createObjectURL(blob);

                window.open(url, '_blank');
            } else {
                noti('File not found');
            }
}

function openFile(key) {
    // Split the key by "." to check if it has an extension
    const fileNameParts = key.split('.');

    // Get the last part of the filename to determine the file type
    const fileType = fileNameParts.length > 1 ? fileNameParts[fileNameParts.length - 1] : undefined;

    // If the fileType is empty or undefined (meaning no extension), open it in the text editor
    if (!fileType || fileType === 'txt' || fileType === 'csv' || fileType === 'plain' || fileType === 'undefined' || fileType === 'uex') {
        loadText(key);
    } else if (fileType === 'html' || fileType === 'xhtml' || fileType === 'htm') {
        executeCode(key);
    } else {
        noti('Unsupported file type.');
    }
}

function renameFile(oldKey) {
    askValue('Enter a new name for the file:', function() {
        const newKey = document.getElementById('askValueInput').value;
        if (!newKey.trim()) {
            noti("No filename provided. File not renamed");
            return;
        }
        if (localStorage.getItem(newKey)) {
            noti('A file with the new name already exists.');
            return;
        }

        const fileContent = localStorage.getItem(oldKey);
        localStorage.removeItem(oldKey);
        localStorage.setItem(newKey, fileContent);
        displayLocalStorage();
        noti('File renamed: ' + oldKey + ' to ' + newKey);
    });
}

function copyFile(key) {
    askValue('Enter a new name for the copied file:', function() {
        const newKey = document.getElementById('askValueInput').value;
        if (!newKey.trim()) {
            noti("No filename provided. File not copied");
            return;
        }
        if (localStorage.getItem(newKey)) {
            noti('A file with the new name already exists.');
            return;
        }

        const fileContent = localStorage.getItem(key);
        localStorage.setItem(newKey, fileContent);
        displayLocalStorage();
        noti('File copied: ' + key + ' to ' + newKey);
    });
}