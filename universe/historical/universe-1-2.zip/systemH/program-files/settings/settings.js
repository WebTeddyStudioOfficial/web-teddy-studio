function changeHint() {
	hint = "Hint: " + document.getElementById('changeHintInput').value;
	if (hint == "Hint: " + document.getElementById('changeHintInput').value) {
		noti('Hint Changed');
		document.getElementById('changeHintInput').value = "";
	} else  {
		noti('There was a problem changing the hint');
		document.getElementById('changeHintInput').value = "";
	}
}

function changePassword() {
	if (document.getElementById('changePasswordInput3').value == publicPassword) {
	if (document.getElementById('changePasswordInput').value == document.getElementById('changePasswordInput2').value) {
		publicPassword = document.getElementById('changePasswordInput').value;
		if (publicPassword == document.getElementById('changePasswordInput').value) {
			noti('Password Changed');
			document.getElementById('changePasswordInput').value = ""; 
			document.getElementById('changePasswordInput2').value = "";
			document.getElementById('changePasswordInput3').value = "";
			} else {
			noti('There was a problem changing your password');
		}
	} else {
		noti('Passwords are not the same');
	}
} else {
	noti('Re-enter your old password.');
	document.getElementById('changePasswordInput').value = ""; 
	document.getElementById('changePasswordInput2').value = "";
	document.getElementById('changePasswordInput3').value = "";
}
}

function changeUsername() {
	username = document.getElementById('changeUsernameInput').value;
	if (username == document.getElementById('changeUsernameInput').value) {
		noti('Username has been changed');
		document.getElementById('changeUsernameInput').value = "";
		document.getElementById('usernameOutput').innerHTML = username;
	} else {
		document.getElementById('changeUsernameInput').value = "";
		noti('There was a problem changing your password');
	}
}

function setNotiTimeout() {
	notiTimeout = document.getElementById('newNotiTimeout').value * 1000;
}

function setConstantSpeed() {
	constantSpeed = document.getElementById('newConstantSpeed').value;
}

function settingsFn(fn) {
	if (fn == "deletePassword") {
		if (document.getElementById('changePasswordInput3').value == publicPassword) {
			publicPassword = "";
			noti('Password has been deleted');
		} else {
			noti('Please enter your password');
		}
		document.getElementById('changePasswordInput3').value = "";
	} else if (fn == "deleteUsername") {
		username = "";
		noti('Username has been deleted');
	} else if (fn == "deleteHint") {
		hint = "";
		noti('Hint has been deleted');
	}
}