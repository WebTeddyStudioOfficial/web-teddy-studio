function renderSettings() {
document.getElementById('settings').innerHTML = `
<div class="tabs">
			<button class="tablink" onClick="openTab('users')">Users</button>
			<button class="tablink" onClick="openTab('settingsAdvanced')">Advanced</button>
			<button class="tabaccIcon" onClick="closeApp('settings')"><img src="systemH/accessibility/close.png"></button>
		</div>
		<div class="tabcontent" id="users">
			<center>
			<p>Change Password</p>
			<button class="accIcon" onClick="openTab('changePassword')"><img src="systemH/accessibility/change.png"></button>
			<p>Change Hint</p>
			<button class="accIcon" onClick="openTab('changeHint')"><img src="systemH/accessibility/change.png"></button>
			<p>Change Username</p>
			<button class="accIcon" onClick="openTab('changeUsername')"><img src="systemH/accessibility/change.png"></button>
			</center>
		</div>

		<div class="tabcontent" id="changePassword">
			<center>
			<span>Enter old Password:</span><br>
				<input class="input" id="changePasswordInput3" type="password"<br><br>
			<span>Enter a new Password:</span><br>
				<input class="input" id="changePasswordInput" type="password"><br>
			<span>Confirm new Password:</span><br>
				<input class="input" id="changePasswordInput2" type="password"><br><br>
				<button class="accIcon" onClick="changePassword()"><img src="systemH/accessibility/accept.png"></button>
				<button class="accIcon" onClick="openTab('users')"><img src="systemH/accessibility/deny.png"></button>
				<button class="accIcon" onClick="settingsFn('deletePassword')"><img src="systemH/accessibility/delete.png"></button>
			</center>
		</div>

		<div class="tabcontent" id="changeHint">
			<center>
				<input class="input" id="changeHintInput" type="text"><br><br>
				<button class="accIcon" onClick="changeHint()"><img src="systemH/accessibility/accept.png"></button>
				<button class="accIcon" onClick="openTab('users')"><img src="systemH/accessibility/deny.png"></button>
				<button class="accIcon" onClick="settingsFn('deleteHint')"><img src="systemH/accessibility/delete.png"></button>
			</center>
		</div>

		<div class="tabcontent" id="changeUsername">
			<center>
				<input class="input" id="changeUsernameInput" type="text"><br><br>
				<button class="accIcon" onClick="changeUsername()"><img src="systemH/accessibility/accept.png"></button>
				<button class="accIcon" onClick="openTab('users')"><img src="systemH/accessibility/deny.png"></button>
				<button class="accIcon" onClick="settingsFn('deleteUsername')"><img src="systemH/accessibility/delete.png"></button>
			</center>
		</div>

		<div class="tabcontent" id="settingsAdvanced">
			<center>
				<button class="tablink" onClick="openTab('notiSettings')">Notification Settings</button>
				<button class="tablink" onClick="openTab('systemConstantSettings')">System Constant Settings</button>
			</center>
		</div>

		<div class="tabcontent" id="systemConstantSettings">
			<center>
				<b>Set Constant Speed (milleseconds)</b>
				<h6><i>The lower you set it, less performance</i></h6>
				<input type="number" min="1" step="1" id="newConstantSpeed" class="input" value="500" onChange="setConstantSpeed()">
			</center>
		</div>

		<div class="tabcontent" id="notiSettings">
			<center>
				<b>Timeout</b><br>
				<input type="number" class="input" onChange="setNotiTimeout()" id="newNotiTimeout" min="1" value="3" max="15"><br><br>
			</center>
		</div>
`;
}

renderSettings();