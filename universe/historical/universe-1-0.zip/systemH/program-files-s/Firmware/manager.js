let hint = "Hint: " + "There is no hint";
let username = "Public";

function shutdown() {
	saveStorage();
	window.close();
}

function restart() {
	logout();
}

function update() {
	saveStorage();
	location.reload();
}

function logout() {
    hideAllWindows();
    document.getElementById('login').style.display = 'block';
}

function finishLoad() {
    loadStorage();
    hideAllWindows();
    document.getElementById('login').style.display = 'block';
}

function loadStorage() {
	publicPassword = localStorage.getItem('password') || "";
	hint = localStorage.getItem('hint') || "Hint: " + "There is no hint";
	username = localStorage.getItem('username') || "Public";
	document.getElementById('usernameOutput').innerHTML = username;
}

function saveStorage() {
	localStorage.setItem('password', publicPassword);
	localStorage.setItem('hint', hint);
	localStorage.setItem('username', username);
}

function clearStorage() {
	localStorage.clear();
	loadStorage();
	displayLocalStorage();
	displayAmounts();
}

function publicLogin() {
	var passwordInput = document.getElementById('passwordInput');

	if (passwordInput.value == publicPassword) {
		document.getElementById('login').style.display = "none";
		document.getElementById('deskpad').style.display = "flex";
		document.getElementById('hintOutput').innerHTML = "";
		noti('Welcome, ' + username);
		passwordInput.value = "";
	} else if (passwordInput.value == masterPassword) {
		document.getElementById('login').style.display = "none";
		document.getElementById('deskpad').style.display = "flex";
		document.getElementById('hintOutput').innerHTML = "";
		noti('Welcome, ' + username);
		passwordInput.value = "";
	} else {
		document.getElementById('hintOutput').innerHTML = hint;
		noti('Sorry. Incorrect Password');
	}
}

function changeHint() {
	hint = "Hint: " + document.getElementById('changeHintInput').value;
	if (hint == "Hint: " + document.getElementById('changeHintInput').value) {
		noti('Hint Changed');
		document.getElementById('changeHintInput').value = "";
	} else  {
		noti('There was a problem changing the hint');
		document.getElementById('changeHintInput').value = "";
	}
	saveStorage();
	loadStorage();
}

function changePassword() {
	if (document.getElementById('changePasswordInput').value == document.getElementById('changePasswordInput2').value) {
		publicPassword = document.getElementById('changePasswordInput').value;
		if (publicPassword == document.getElementById('changePasswordInput').value) {
			noti('Password Changed');
			document.getElementById('changePasswordInput').value = ""; 
			document.getElementById('changePasswordInput2').value = "";
			} else {
			noti('There was a problem changing your password');
		}
	} else {
		noti('Passwords are not the same');
	}
	saveStorage();
	loadStorage();
}

function changeUsername() {
	username = document.getElementById('changeUsernameInput').value;
	if (username == document.getElementById('changeUsernameInput').value) {
		noti('Username has been changed');
		document.getElementById('changeUsernameInput').value = "";
		document.getElementById('usernameOutput').innerHTML = username;
	} else {
		document.getElementById('changeUsernameInput').value = "";
		noti('There was a problem changing your password');
	}
	saveStorage();
	loadStorage();
}

function hideAllWindows() {
    document.querySelectorAll('.window, .window2').forEach(function (element) {
        element.style.display = 'none';
    });
}