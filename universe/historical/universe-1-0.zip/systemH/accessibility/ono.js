function noti(message) {
    var noti = document.getElementById('notification');
    if (noti) {
        var p = document.getElementById('p');
        noti.style.display = "block";
        p.innerHTML = message;
        setTimeout(function() {
            p.innerHTML = "";
            noti.style.display = "none";
        }, 3000);
    }
}

window.onerror = function(message, source, lineno, colno, error) {
    var errorMessage = error ? (error.message || error.toString()) : message;
    noti("Error: " + errorMessage);
    return false;
};
