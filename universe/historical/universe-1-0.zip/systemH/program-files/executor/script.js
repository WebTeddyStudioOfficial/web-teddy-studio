function runScript() {
    const fileInput = document.getElementById('executeInput');
    const file = fileInput.files[0];
    
    if (!file) {
        noti('Please select a file');
        return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(event) {
        const scriptContent = event.target.result;
        try {
            eval(scriptContent); // Execute the JavaScript code
            
            // Call runExecutable() if it exists in the loaded script
            if (typeof runExecutable === 'function') {
                runExecutable();
            } else {
                alert('This file is missing the execute function, is it for Universe?');
            }
        } catch (error) {
            console.error('Error executing script:', error);
            noti('This file has a problem, check console for details');
        }
    };
    reader.readAsText(file);
	}