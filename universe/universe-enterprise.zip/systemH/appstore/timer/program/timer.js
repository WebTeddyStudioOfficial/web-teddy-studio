let timer_timer;
let timer_isRunning = false;
let timer_seconds = 0;
let timer_minutes = 0;
let timer_hours = 0;

function timer_start_stop() {
  if (timer_isRunning) {
    clearInterval(timer_timer);
    document.getElementById('timer-start-stop').innerText = 'Start';
    timer_isRunning = false;
  } else {
    timer_timer = setInterval(timer_runTimer, 1000);
    document.getElementById('timer-start-stop').innerText = 'Stop';
    timer_isRunning = true;
  }
}

function timer_reset() {
  clearInterval(timer_timer);
  document.getElementById('timer-start-stop').innerText = 'Start';
  timer_isRunning = false;
  timer_seconds = 0;
  timer_minutes = 0;
  timer_hours = 0;
  timer_updateDisplay();
}

function timer_runTimer() {
  timer_seconds++;
  if (timer_seconds === 60) {
    timer_seconds = 0;
    timer_minutes++;
    if (timer_minutes === 60) {
      timer_minutes = 0;
      timer_hours++;
    }
  }
  timer_updateDisplay();
}

function timer_updateDisplay() {
  const formattedTime = timer_pad(timer_hours) + ':' + timer_pad(timer_minutes) + ':' + timer_pad(timer_seconds);
  document.getElementById('timer-display').innerText = formattedTime;
}

function timer_pad(num) {
  return (num < 10) ? '0' + num : num;
}