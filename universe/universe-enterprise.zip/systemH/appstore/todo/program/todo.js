function TodoaddTask() {
            const taskInput = document.getElementById('Todo-taskInput');
            const timeInput = document.getElementById('Todo-timeInput');
            const taskContent = taskInput.value.trim();
            const taskTime = timeInput.value;
            const taskList = document.getElementById('Todo-taskList');

            if (taskContent !== '') {
                const li = document.createElement('li');
                li.textContent = taskContent;
                li.dataset.time = taskTime; // Store task time in dataset
                li.addEventListener('click', function() {
                    ask('Remove this Task?', function() {
						li.remove();
					});
                });
                taskList.appendChild(li);
                taskInput.value = '';
                timeInput.value = '00:00';
            } else {
                noti('Please enter a task.');
            }
        }

        function TodoScheduleNotification(task, time) {
            const currentTime = TodoGetCurrentTime();
            if (time >= currentTime) {
                const notificationTime = new Date();
                const [hours, minutes] = time.split(':');
                notificationTime.setHours(parseInt(hours));
                notificationTime.setMinutes(parseInt(minutes));
                const delay = notificationTime.getTime() - Date.now();
                setTimeout(function() {
                    noti('Reminder: ' + task.textContent); // Display reminder notification
                }, delay);
            } else {
                noti('Please enter a future time');
            }
        }

        function TodoGetCurrentTime() {
            const currentDate = new Date();
            const currentHour = currentDate.getHours().toString().padStart(2, '0');
            const currentMinute = currentDate.getMinutes().toString().padStart(2, '0');
            return currentHour + ':' + currentMinute;
        }