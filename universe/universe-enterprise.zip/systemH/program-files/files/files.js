function displayLocalStorage() {
    displayAmounts();
    var localStorageContents = "";

    for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);

        if (systemFiles.includes(key)) {
            continue;
        } else if (appFiles.includes(key)) {
			continue;
		} else if (quickLoad.includes(key)) {
            continue;
        }

        var value = localStorage.getItem(key);
        var fileSize = formatBytes((key.length + value.length) * 2); // Calculate size

        localStorageContents += '<div ondblclick="openFile(\'' + key + '\')" class="files-section">' +
            '<span class="files-span">S:/Files/</span>' + key +
            '<button class="files-section-accIcon" onmouseout="resetPlaceholder()" onmouseover="filesfn(\'Delete\')" onclick="deleteItem(\'' + key + '\')"><img src="systemH/accessibility/delete.png"></button>' +
            '<button class="files-section-accIcon" onmouseout="resetPlaceholder()" onmouseover="filesfn(\'Rename\')" onclick="renameFile(\'' + key + '\')"><img src="systemH/accessibility/rename.png"></button>' +
            '<button class="files-section-accIcon" onmouseout="resetPlaceholder()" onmouseover="filesfn(\'Copy\')" onclick="copyFile(\'' + key + '\')"><img src="systemH/accessibility/copy.png"></button>' +
            '<button class="files-section-accIcon" onmouseout="resetPlaceholder()" onmouseover="filesfn(\'Download\')" onClick="downloadFile(\'' + key + '\')"><img src="systemH/accessibility/download.png"></button>' +
            '<button class="files-section-accIcon" onmouseout="resetPlaceholder()" onmouseover="filesfn(\'Execute\')" onClick="filesExecute(\'' + key + '\', event)"><img src="systemH/accessibility/execute.png"></button>' +
            '<span class="filesizespan"><b>(' + fileSize + ')</b>&nbsp;</span>' +
        '</div>';
    }

    document.getElementById("localStorageContents").innerHTML = localStorageContents;

    if (localStorageContents === "") {
        document.getElementById('localStorageContents').innerHTML = "No Files";
    }
}

function resetPlaceholder() {
    document.getElementById('filesPlaceholder').innerHTML = "...";
}

function filesfn(fn) {
    document.getElementById('filesPlaceholder').innerHTML = fn;
}

function deleteItem(key) {
 	ask('Are you sure you want to delete this?', function() {
        localStorage.removeItem(key);
    	displayLocalStorage();
    	noti('<b>Deleted: </b>' + key);
		closeAsk();
    });
}

function downloadFile(key) {
    askValue('Please enter a filename for the download', function() {
        var textToDownload = localStorage.getItem(key);
        var filename = document.getElementById('askValueInput').value;
        
        if (!filename || !filename.trim()) {
            noti('Please enter a filename');
            return;
        }
        
        var blob = new Blob([textToDownload], { type: 'text' });
        var link = document.createElement('a');
        link.download = filename;
        link.href = window.URL.createObjectURL(blob);
        link.click();
	});
}

function filesExecute(key) {
    const executableCode = localStorage.getItem(key);
    
    if (!executableCode) {
        noti('No File Contents');
        return;
    }
    
    try {
        eval(executableCode);
        
        if (typeof runExecutable !== 'function') {
            noti('This executable is missing the run code. Is it for Universe?');
            return;
        }
        
        runExecutable();
    } catch (error) {
        noti('This executable is corrupt');
    }
}

function formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
}

function displayAmounts() {
    var totalStorage = 0;
    var systemStorage = 0;
    var totalFiles = 0;

    // Count the total storage and system storage
    for (var i = 0; i < localStorage.length; i++) {
        var key = localStorage.key(i);
        var value = localStorage.getItem(key);

        totalStorage += (key.length + value.length) * 2;

        if (systemFiles.includes(key)) {
            systemStorage += (key.length + value.length) * 2;
        } else {
            totalFiles++; // Increment totalFiles only if it's not a system file
        }
    }

    // Ensure totalFiles is not negative
    if (totalFiles < 0) {
        totalFiles = 0;
    }

    // Display the information
    document.getElementById("totalStorage").textContent = 'Total Size: ' + formatBytes(totalStorage);
    document.getElementById("totalFiles").textContent = 'Files: ' + totalFiles;

    document.getElementById("systemStorage").textContent = 'System Size: ' + formatBytes(systemStorage);
    document.getElementById("systemFiles").textContent = 'System Files: ' + systemFiles.length;
}

function executeCode(code) {
	var htmlContent = localStorage.getItem(code);

            if (htmlContent) {
                var blob = new Blob([htmlContent], { type: 'text/html' });
                var url = URL.createObjectURL(blob);

                window.open(url, '_blank');
            } else {
                noti('File not found');
            }
}

function openFile(key) {
    // Split the key by "." to check if it has an extension
    const fileNameParts = key.split('.');

    // Get the last part of the filename to determine the file type
    const fileType = fileNameParts.length > 1 ? fileNameParts[fileNameParts.length - 1] : undefined;

    // If the fileType is empty or undefined (meaning no extension), open it in the text editor
    if (!fileType || fileType === 'txt' || fileType === 'csv' || fileType === 'plain' || fileType === 'undefined' || fileType === 'uex') {
        loadText(key);
    } else if (fileType === 'html' || fileType === 'xhtml' || fileType === 'htm') {
        executeCode(key);
    } else {
        noti('Unsupported file type.');
    }
}

function renameFile(oldKey) {
    askValue('Enter a new name for the file:', function() {
        const newKey = document.getElementById('askValueInput').value;
        if (!newKey.trim()) {
            noti("No filename provided. File not renamed");
            return;
        }
        if (localStorage.getItem(newKey)) {
            noti('A file with the new name already exists.');
            return;
        }

        const fileContent = localStorage.getItem(oldKey);
        localStorage.removeItem(oldKey);
        localStorage.setItem(newKey, fileContent);
        displayLocalStorage();
        noti('<b>File renamed to: </b>' + newKey);
    });
}

function copyFile(key) {
    askValue('Enter a new name for the copied file:', function() {
        const newKey = document.getElementById('askValueInput').value;
        if (!newKey.trim()) {
            noti("No filename provided. File not copied");
            return;
        }
        if (localStorage.getItem(newKey)) {
            noti('A file with the new name already exists.');
            return;
        }

        const fileContent = localStorage.getItem(key);
        localStorage.setItem(newKey, fileContent);
        displayLocalStorage();
        noti('<b>Copied File: </b>' + newKey);
    });
}