function changeHint() {
	hint = "Hint: " + document.getElementById('changeHintInput').value;
	if (hint == "Hint: " + document.getElementById('changeHintInput').value) {
		noti('Hint Changed');
		document.getElementById('changeHintInput').value = "";
	} else  {
		noti('There was a problem changing the hint');
		document.getElementById('changeHintInput').value = "";
	}
}

function changePassword() {
	if (document.getElementById('changePasswordInput3').value == publicPassword) {
	if (document.getElementById('changePasswordInput').value == document.getElementById('changePasswordInput2').value) {
		publicPassword = document.getElementById('changePasswordInput').value;
		if (publicPassword == document.getElementById('changePasswordInput').value) {
			noti('Password Changed');
			document.getElementById('changePasswordInput').value = ""; 
			document.getElementById('changePasswordInput2').value = "";
			} else {
			noti('There was a problem changing your password');
		}
	} else {
		noti('Passwords are not the same');
	}
		} else {
			noti('Old password incorrect');
		}
}

function changeUsername() {
	username = document.getElementById('changeUsernameInput').value;
	if (username == document.getElementById('changeUsernameInput').value) {
		noti('Username has been changed');
		document.getElementById('changeUsernameInput').value = "";
		document.getElementById('usernameOutput').innerHTML = username;
	} else {
		document.getElementById('changeUsernameInput').value = "";
		noti('There was a problem changing your password');
	}
}

function changeTabsColor() {
	var tabsBar = document.querySelectorAll('.tabs');
	tabsBar.forEach(function(tabsBar) {
		tabsBar.style.borderColor = document.getElementById('changeColorsTabs').value;
				   });
}

function changeWindowColor() {
	var window = document.querySelectorAll('.window');
	var tabcontent = document.querySelectorAll('.tabcontent');
	window.forEach(function(window) {
		window.style.backgroundColor = document.getElementById('changeColorsWindow').value;
		window.style.borderColor = document.getElementById('changeColorsWindow').value;
	});
	tabcontent.forEach(function(tabcontent) {
		tabcontent.style.backgroundColor = document.getElementById('changeColorsWindow').value;
		tabcontent.style.borderColor = document.getElementById('changeColorsWindow').value;
	});
}

function setNotiTimeout() {
	notiTimeout = document.getElementById('newNotiTimeout').value * 1000;
}

function setConstantSpeed() {
	constantSpeed = document.getElementById('newConstantSpeed').value;
}

function settingsFn(fn) {
	if (fn == "deletePassword") {
		if (document.getElementById('changePasswordInput3').value == publicPassword) {
			publicPassword = "";
			noti('Password has been deleted');
			document.getElementById('changePasswordInput3').value = "";
		} else if (document.getElementById('changePasswordInput3').value == masterPassword) {
			publicPassword = "";
			noti('Password has been deleted');
			document.getElementById('changePasswordInput3').value = "";
		} else {
			noti('Please enter your old password');
			document.getElementById('changePasswordInput3').value = "";
		}
	} else if (fn == "deleteUsername") {
		username = "";
		noti('Username has been deleted');
	} else if (fn == "deleteHint") {
		hint = "";
		noti('Hint has been deleted');
	}
}

function changeDockBorderColor() {
	var border1 = document.querySelectorAll('.dock');
	var border2 = document.querySelectorAll('.dock-accIcon');
	border1.forEach(function(border1) {
		border1.style.borderColor = document.getElementById('changeColorsDockBorder').value;
	});
	border2.forEach(function(border2) {
		border2.style.borderColor = document.getElementById('changeColorsDockBorder').value;
	});
}

function changeDockColor() {
	var dock = document.querySelectorAll('.dock');
	dock.forEach(function(dock) {
		dock.style.backgroundColor = document.getElementById('changeColorsDock').value;
	});
}