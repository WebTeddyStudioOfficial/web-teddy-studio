function constantAPIS() {

    const wifiStatus = navigator.onLine ? 'Online' : 'Offline';
	const wifiIMG = document.getElementById('linternetIMG');
	const wifiIMG2 = document.getElementById('dinternetIMG');


    document.getElementById('ltime').innerHTML = currentTime;
    document.getElementById('ldate').innerHTML = currentDateStr;


	if (wifiStatus == "Online") {
		wifiIMG.src = "systemH/comm/internet.png";
		wifiIMG2.src = "systemH/comm/internet.png";
	} else {
		wifiIMG.src = "systemH/comm/nointernet.png";
		wifiIMG2.src = "systemH/comm/nointernet.png";
	}
}

function constantAPISupdate() {
    if ('getBattery' in navigator) {
        navigator.getBattery().then(function(battery) {
            updateBatteryLevel(battery.level, battery.charging);
            battery.addEventListener('levelchange', function() {
                updateBatteryLevel(battery.level, battery.charging);
            });
            battery.addEventListener('chargingchange', function() {
                updateBatteryLevel(battery.level, battery.charging);
            });
        });
    } else {
        console.log("Battery information not supported.");
    }
}

function updateBatteryLevel(level, isCharging) {
    const batteryPercentage = Math.floor(level * 100);
    const batteryElement = document.getElementById('lbatteryIMG');
	const batteryElement2 = document.getElementById('dbatteryIMG');
    const batteryStatusElement = document.getElementById('lbattery');

    batteryStatusElement.innerHTML = batteryPercentage + '%';

    if (isCharging) {
    batteryElement.src = "systemH/comm/batteryCA.png";
    batteryElement2.src = "systemH/comm/batteryCA.png";
} else if (batteryPercentage >= 75) {
    batteryElement.src = "systemH/comm/battery100.png";
    batteryElement2.src = "systemH/comm/battery100.png";
} else if (batteryPercentage >= 50) {
    batteryElement.src = "systemH/comm/battery75.png";
    batteryElement2.src = "systemH/comm/battery75.png";
} else if (batteryPercentage >= 25) {
    batteryElement.src = "systemH/comm/battery50.png";
    batteryElement2.src = "systemH/comm/battery50.png";
} else if (batteryPercentage >= 0) {
    batteryElement.src = "systemH/comm/battery25.png";
    batteryElement2.src = "systemH/comm/battery25.png";
} else {
    batteryElement.src = "systemH/accessibility/deny.png";
    batteryElement2.src = "systemH/accessibility/deny.png";
}
}