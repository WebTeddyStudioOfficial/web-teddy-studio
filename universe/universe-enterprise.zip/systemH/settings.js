let textSaved = false;
let savedText = null;
var notiTimeout = 3000;
var ntype = "normal";
let logStatus = false;
var efx = new Audio('systemH/sysfx/efx.mp3');
var nfx = new Audio('systemH/sysfx/nfx.mp3');
let alertSaveText = "";
let hint = "Hint: " + "There is no hint";
let username = "Public";
let constantSpeed = 1;
let constantInterval;
const keysToKeep = [
	"username",
	"password",
	"hint",
	"selectedIconIndex",
	"appscripts",
	"appstyles",
	"appcontent",
	"appsdesk",
	"installedApps",
	"appFiles",
	"theme",
	"quickLoadData"
];
const systemFiles = [
	"username",
	"password",
	"hint",
	"selectedIconIndex",
	"appscripts",
	"appstyles",
	"appcontent",
	"appsdesk",
	"installedApps",
	"appFiles",
	"theme",
	"quickLoadData"
];
let appFiles = [
	
];
let currentIconIndex = 0;
const iconPaths = [
    'systemH/personalization/usericon1.png',
    'systemH/personalization/usericon2.png',
    'systemH/personalization/usericon3.png',
    'systemH/personalization/usericon4.png',
    'systemH/thumbnails/user.png'
];

let quickLoad = [
	
];
const contextMenu = document.getElementById('customContextMenu');
let appscripts = [];
let appstyles = [];
let appcontent = "";
let appsdesk = "";
let installedApps = [];

const currentDate = new Date();
    const currentHour = currentDate.getHours().toString().padStart(2, '0');
    const currentMinute = currentDate.getMinutes().toString().padStart(2, '0');
    const currentTime = currentHour + ':' + currentMinute;
    const currentDateStr = currentDate.toDateString();
let inactivityTimer;
const inactivityThreshold = 1200000;
let theme = 'light';
let parentalControls = false;