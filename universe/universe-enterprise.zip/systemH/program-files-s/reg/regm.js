function register() {
    if (publicPassword !== "") {
        hideAllWindows();
        document.getElementById('login').style.display = "block";
    } else if (publicPassword == "") {
		hideAllWindows();
        document.getElementById('register').style.display = "block";
		openTab('registerStart');
    } else if (!publicPassword) {
		noti('Universe is corrupt');
	}
}

function registerAction(arg) {
	if (arg == "skip") {
		hideAllWindows();
		document.getElementById('login').style.display = "block";
	} else if (arg == "unskip") {
		hideAllWindows();
		document.getElementById('register').style.display = "block";
		openTab('registerStart');
	} else if (arg == "userVerify") {
		let input1 = document.getElementById('registerPasswordInput');
		let input2 = document.getElementById('registerPasswordInput2');
		let input3 = document.getElementById('registerUsernameInput');
		if (input1.value == input2.value) {
			if (input3.value !== "") {
				ask('This will delete all files <b>Continue?</b>', function() {
				openTab('regUserComplete');
				setTimeout(function() {
					logout();
					clearStorage();
					noti('Thanks for registering Universe');
					setTimeout(function() {
						publicPassword = input2.value;
						username = input3.value;
						setTimeout(function () {
							input1.value = "";
							input2.value = "";
							input3.value = "";
						}, 1000);
						noti('Your computer will restart to finish applying updates<br><b><i>3s</i></b>');
						setTimeout(function() {
							restart();
						}, 3000);
					}, 3000);
				  }, 3000);	
				});			  
			} else {
				noti('Please enter a username');
			}
		} else {
			input1.value = "";
			input2.value = "";
			noti('Password are not the same');
		}
	} else if (arg == "cancel") {
		location.reload();
	}
}