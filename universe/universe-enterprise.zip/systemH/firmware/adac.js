function shutdown() {
	saveStorage();
	window.close();
}

function restart() {
	saveStorage();
	location.reload();
}

function logout() {
	logStatus = false;
    hideAllWindows();
    document.getElementById('loginMenu').style.display = 'block';
}

function finishLoad() {
    loadStorage();
    hideAllWindows();
	logout();
    constantRunning();
	setInterval(constantRunning, constantSpeed);
	constantInterval = setInterval(constantRunning, constantSpeed);
	loadApps();
	window.addEventListener('resize', updateWindowSize);
	document.addEventListener("mousemove", handleActivity);
	document.addEventListener("keypress", handleActivity);
	loadAppFiles();
	loadTheme();
    quickLoadLoader();
    var inputs = document.querySelectorAll('input');

    inputs.forEach(function(input) {
        input.autocomplete = "off";
    });
}

function constantRunning() {
    saveStorage();
    loadStorage();
	displayAmounts();
    checkPassword();
	updateWindowSize();
    constantAPISupdate();
    constantAPIS();
	updateBatteryLevel();
	checkForTextSave();
    quickLoadSaver();
}
    
function quickLoadAdder(src, type) {
    quickLoad.push({src: src, type: type});
}

function quickLoadLoader() {
    var savedData = localStorage.getItem('quickLoadData');
    if (savedData) {
        quickLoad = JSON.parse(savedData);
        preloadUrls();
    }
}

function preloadUrls() {
    for (var i = 0; i < quickLoad.length; i++) {
        var url = quickLoad[i].src;
        var type = quickLoad[i].type;
        var preload = document.createElement('link');
        preload.href = url;
        preload.rel = 'preload';
        preload.as = type;
        document.head.appendChild(preload);
    }
}

function quickLoadSaver() {
    localStorage.setItem('quickLoadData', JSON.stringify(quickLoad));
}

function saveTheme() {
	localStorage.setItem('theme', theme);
}

function loadTheme() {
	theme = localStorage.getItem('theme') || 'light';
	toggletheme();
	toggletheme();
}

function saveAppFiles() {
    localStorage.setItem('appFiles', JSON.stringify(appFiles));
}

function loadAppFiles() {
    appFiles = JSON.parse(localStorage.getItem('appFiles')) || [];
}

function checkPassword() {
    if (!publicPassword == "") {
        document.getElementById('passwordInput').style.display = "block";
		document.getElementById('h').style.display = "none";
    } else {
        document.getElementById('passwordInput').style.display = "none";
		document.getElementById('h').style.display = "block";
    }
}

function loadStorage() {
	publicPassword = localStorage.getItem('password') || "";
	hint = localStorage.getItem('hint') || "Hint: " + "There is no hint";
	username = localStorage.getItem('username') || "Public";
	document.getElementById('usernameOutput').innerHTML = username;
}

function saveStorage() {
	localStorage.setItem('password', publicPassword);
	localStorage.setItem('hint', hint);
	localStorage.setItem('username', username);
}

function clearStorage() {
    ask('Are you sure?', function() {
        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (!keysToKeep.includes(key)) {
                localStorage.removeItem(key);
            }
        }
        loadStorage();
    });
}

function hideAllWindows() {
    document.querySelectorAll('.window, .window2, .deskpad, .tabcontent').forEach(function (element) {
        element.style.display = 'none';
    });
}

// Function to update window size
function updateWindowSize() {
    var dockElements = document.querySelectorAll('.dock');
    var windowElements = document.querySelectorAll('.window, .window2');

    dockElements.forEach(function(dockElement) {
        var dockHeight = dockElement.offsetHeight;
        windowElements.forEach(function(windowElement) {
            windowElement.style.height = 'calc(100% - ' + dockHeight + 'px)';
        });
    });
}

function resetTimer() {
    clearTimeout(inactivityTimer);
    inactivityTimer = setTimeout(handleInactive, inactivityThreshold);
}

function handleInactive() {
    logout();
}

function handleActivity() {
    resetTimer();
}