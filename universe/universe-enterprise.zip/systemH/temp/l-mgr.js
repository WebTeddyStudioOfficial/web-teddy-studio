function publicLogin() {
	var passwordInput = document.getElementById('passwordInput');

	if (passwordInput.value == publicPassword) {
		document.getElementById('login').style.display = "none";
		document.getElementById('deskpad').style.display = "flex";
		document.getElementById('hintOutput').innerHTML = "";
		noti('Welcome, ' + username);
		passwordInput.value = "";
		logStatus = true;
	} else if (passwordInput.value == masterPassword) {
		document.getElementById('login').style.display = "none";
		document.getElementById('deskpad').style.display = "flex";
		document.getElementById('hintOutput').innerHTML = "";
		noti('Welcome, ' + username);
		passwordInput.value = "";
		logStatus = true;
	} else {
		document.getElementById('hintOutput').innerHTML = hint;
		passwordInput.value = "";
		noti('Sorry. Incorrect Password');
		logStatus = false;
	}
}